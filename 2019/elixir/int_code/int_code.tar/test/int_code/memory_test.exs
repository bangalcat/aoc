defmodule IntCode.MemoryTest do
  use ExUnit.Case

  alias IntCode.Memory

  doctest IntCode.Memory, import: true
end
